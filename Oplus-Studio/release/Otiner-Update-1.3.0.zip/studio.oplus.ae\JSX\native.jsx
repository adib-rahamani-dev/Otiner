/* Otiner Studio - native AEP snapshot save/import for exact layer fidelity. */
(function (global) {
    var OPLUS = global.OPLUS = global.OPLUS || {};
    var nativeApi = OPLUS.nativeCopy = OPLUS.nativeCopy || {};
    var PRIMARY_MARKER = "__OTINER_NATIVE_PRIMARY__\n";
    var DEPENDENCY_MARKER = "__OTINER_NATIVE_DEPENDENCY__\n";

    function read(object, name, fallback) {
        try { if (object !== null && object !== undefined && object[name] !== undefined) { return object[name]; } }
        catch (ignore) {}
        return fallback;
    }

    function warn(warnings, code, message, details) {
        var item = { code: code, message: String(message || code) };
        var key;
        details = details || {};
        for (key in details) { if (details.hasOwnProperty(key)) { item[key] = details[key]; } }
        if (warnings) { warnings.push(item); }
        try { if (typeof OPLUS.log === "function") { OPLUS.log("native.warning", item); } } catch (ignoreLog) {}
    }

    function selectedIndexMap(comp) {
        var result = {};
        var selected = comp.selectedLayers || [];
        var i;
        for (i = 0; i < selected.length; i += 1) { result[selected[i].index] = true; }
        return result;
    }

    function propertyLayerReferences(layer) {
        var result = [];
        var seen = {};
        function add(value) {
            var index = Math.round(Number(value));
            if (isFinite(index) && index > 0 && !seen[index]) { seen[index] = true; result.push(index); }
        }
        function scan(group) {
            var i;
            var child;
            var typeName;
            var k;
            for (i = 1; i <= Number(read(group, "numProperties", 0)); i += 1) {
                try {
                    child = group.property(i);
                    if (read(child, "numKeys", undefined) !== undefined &&
                            read(child, "propertyValueType", undefined) !== undefined) {
                        typeName = String(read(child, "propertyValueType", "")).toUpperCase();
                        if (typeName.indexOf("LAYER_INDEX") >= 0) {
                            if (child.numKeys > 0) {
                                for (k = 1; k <= child.numKeys; k += 1) { add(child.keyValue(k)); }
                            } else { add(child.value); }
                        }
                    } else if (child) { scan(child); }
                } catch (ignoreProperty) {}
            }
        }
        scan(layer);
        return result;
    }

    function dependencyIndexMap(comp, primary) {
        var keep = {};
        var queue = [];
        var key;
        var i;
        var layer;
        var parent;
        var matte;
        var references;
        for (key in primary) {
            if (primary.hasOwnProperty(key) && primary[key]) { keep[key] = true; queue.push(Number(key)); }
        }
        for (i = 0; i < queue.length; i += 1) {
            try { layer = comp.layer(queue[i]); } catch (ignoreLayer) { layer = null; }
            if (!layer) { continue; }
            parent = read(layer, "parent", null);
            matte = read(layer, "trackMatteLayer", null);
            if (parent && !keep[parent.index]) { keep[parent.index] = true; queue.push(parent.index); }
            if (matte && !keep[matte.index]) { keep[matte.index] = true; queue.push(matte.index); }
            references = propertyLayerReferences(layer);
            for (key = 0; key < references.length; key += 1) {
                if (!keep[references[key]]) { keep[references[key]] = true; queue.push(references[key]); }
            }
        }
        return keep;
    }

    function sanitizeId(value) {
        return String(value || "asset").replace(/[^A-Za-z0-9_-]/g, "_").substring(0, 80);
    }

    function findCompById(itemId) {
        var i;
        var item;
        for (i = 1; i <= app.project.numItems; i += 1) {
            item = app.project.item(i);
            try { if (item instanceof CompItem && item.id === itemId) { return item; } } catch (ignore) {}
        }
        return null;
    }

    global.OPLUS_NATIVE_RESTORE_PROJECT = function () {
        var state = global.OPLUS_NATIVE_RESTORE_STATE;
        var originalFile;
        var restoredComp;
        if (!state || !state.path) { return; }
        originalFile = new File(state.path);
        try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); } catch (ignoreClose) {}
        try {
            app.open(originalFile);
            restoredComp = findCompById(state.activeItemId);
            if (restoredComp) { try { restoredComp.openInViewer(); } catch (ignoreViewer) {} }
        } catch (restoreError) {
            try { alert("Otiner saved the original project safely at:\n" + state.path +
                "\n\nOpen it manually. Automatic reopen failed:\n" + restoreError.toString()); } catch (ignoreAlert) {}
        }
        global.OPLUS_NATIVE_RESTORE_STATE = null;
    };

    function saveSelection(assetDir, assetId, warnings) {
        var comp = OPLUS.util.requireActiveComp();
        var originalFile = app.project.file;
        var activeItemId = read(comp, "id", 0);
        var primary = selectedIndexMap(comp);
        var selectedLayerCount = comp.selectedLayers ? comp.selectedLayers.length : 0;
        var keep;
        var snapshotComp;
        var snapshotName = "__OTINER_NATIVE_" + sanitizeId(assetId) + "__";
        var nativeFile = new File(OPLUS.util.normalizePath(assetDir + "/native.aep"));
        var i;
        var originalComment;
        var saveError = null;
        if (!originalFile) {
            throw new Error("OPLUS_NATIVE_PROJECT_MUST_BE_SAVED: Save the After Effects project once before saving an exact Otiner asset.");
        }
        if (!comp.selectedLayers || comp.selectedLayers.length === 0) {
            throw new Error("OPLUS_NO_SELECTED_LAYERS: Select at least one layer.");
        }
        app.project.save(originalFile);
        try {
            keep = dependencyIndexMap(comp, primary);
            snapshotComp = comp.duplicate();
            snapshotComp.name = snapshotName;
            try { snapshotComp.comment = "Otiner native asset " + String(assetId || ""); } catch (ignoreComment) {}
            for (i = 1; i <= snapshotComp.numLayers; i += 1) {
                originalComment = String(read(snapshotComp.layer(i), "comment", ""));
                snapshotComp.layer(i).comment = (primary[i] ? PRIMARY_MARKER : DEPENDENCY_MARKER) + originalComment;
            }
            for (i = snapshotComp.numLayers; i >= 1; i -= 1) {
                if (!keep[i]) {
                    snapshotComp.layer(i).remove();
                }
            }
            app.project.reduceProject([snapshotComp]);
            app.project.save(nativeFile);
            if (!nativeFile.exists || nativeFile.length < 1) {
                throw new Error("OPLUS_NATIVE_SAVE_FAILED: After Effects did not create native.aep.");
            }
        } catch (error) {
            saveError = error;
        }
        global.OPLUS_NATIVE_RESTORE_STATE = { path: originalFile.fsName, activeItemId: activeItemId };
        app.scheduleTask("OPLUS_NATIVE_RESTORE_PROJECT()", 900, false);
        if (saveError) { throw saveError; }
        return {
            fileName: "native.aep",
            filePath: nativeFile.fsName,
            compName: snapshotName,
            selectedLayerCount: selectedLayerCount,
            restoreScheduled: true
        };
    }

    function newItemIdsBeforeImport() {
        var result = {};
        var i;
        for (i = 1; i <= app.project.numItems; i += 1) { result[app.project.item(i).id] = true; }
        return result;
    }

    function findImportedComp(name, oldIds) {
        var i;
        var item;
        for (i = 1; i <= app.project.numItems; i += 1) {
            item = app.project.item(i);
            try {
                if (!oldIds[item.id] && item instanceof CompItem && item.name === name) { return item; }
            } catch (ignore) {}
        }
        return null;
    }

    function installedEffectMap() {
        var result = {};
        var effects;
        var i;
        try { effects = app.effects; } catch (ignoreEffects) { effects = null; }
        if (!effects) { return null; }
        for (i = 0; i < effects.length; i += 1) {
            try { if (effects[i].matchName) { result[String(effects[i].matchName)] = true; } } catch (ignoreEffect) {}
        }
        return result;
    }

    function removeUnavailableEffects(layer, installed, warnings) {
        var parade;
        var i;
        var effect;
        var matchName;
        var canAdd;
        if (!installed) { return; }
        try { parade = layer.property("ADBE Effect Parade"); } catch (ignoreParade) { parade = null; }
        if (!parade) { return; }
        for (i = parade.numProperties; i >= 1; i -= 1) {
            effect = parade.property(i);
            matchName = String(read(effect, "matchName", ""));
            canAdd = false;
            try { canAdd = !!parade.canAddProperty(matchName); } catch (ignoreCanAdd) {}
            if (matchName && !installed[matchName] && !canAdd) {
                warn(warnings, "EFFECT_NOT_INSTALLED",
                    "An effect was skipped because it is not installed in this After Effects.", {
                        layer: read(layer, "name", ""), effect: read(effect, "name", matchName), matchName: matchName
                    });
                try { effect.remove(); } catch (ignoreRemove) {}
            }
        }
    }

    function stripMarker(layer) {
        var comment = String(read(layer, "comment", ""));
        var primary = comment.indexOf(PRIMARY_MARKER) === 0;
        if (primary) { comment = comment.substring(PRIMARY_MARKER.length); }
        else if (comment.indexOf(DEPENDENCY_MARKER) === 0) { comment = comment.substring(DEPENDENCY_MARKER.length); }
        try { layer.comment = comment; } catch (ignoreComment) {}
        return primary;
    }

    function normalizeFileKey(value) {
        var path = String(value || "").replace(/\\/g, "/");
        try { if ($.os && String($.os).toLowerCase().indexOf("windows") >= 0) { path = path.toLowerCase(); } }
        catch (ignore) {}
        return path;
    }

    function relinkPackagedMedia(oldIds, assetDir, manifest, warnings) {
        var byOriginal = {};
        var i;
        var entry;
        var item;
        var originalPath;
        var replacement;
        manifest = manifest || [];
        for (i = 0; i < manifest.length; i += 1) {
            entry = manifest[i] || {};
            if (entry.originalPath && entry.packagedPath && !byOriginal[normalizeFileKey(entry.originalPath)]) {
                byOriginal[normalizeFileKey(entry.originalPath)] = entry;
            }
        }
        for (i = 1; i <= app.project.numItems; i += 1) {
            item = app.project.item(i);
            if (oldIds[item.id]) { continue; }
            try {
                if (!(item instanceof FootageItem) || !item.file) { continue; }
                originalPath = normalizeFileKey(item.file.fsName);
                entry = byOriginal[originalPath];
                if (!entry) { continue; }
                replacement = new File(OPLUS.util.normalizePath(assetDir + "/" + entry.packagedPath));
                if (!replacement.exists) {
                    warn(warnings, "PACKAGED_MEDIA_MISSING", "A packaged source file is missing.", {
                        source: item.name, path: replacement.fsName
                    });
                    continue;
                }
                try {
                    if (entry.sequence && typeof item.replaceWithSequence === "function") {
                        item.replaceWithSequence(replacement, !!entry.forceAlphabetical);
                    } else { item.replace(replacement); }
                } catch (relinkError) {
                    warn(warnings, "PACKAGED_MEDIA_RELINK_FAILED", relinkError.toString(), {
                        source: item.name, path: replacement.fsName
                    });
                }
            } catch (ignoreItem) {}
        }
    }

    function importSelection(assetDir, compName, options) {
        var destination = OPLUS.util.requireActiveComp();
        var nativeFile = new File(OPLUS.util.normalizePath(assetDir + "/native.aep"));
        var oldIds;
        var importOptions;
        var sourceComp;
        var copiedBySourceIndex = {};
        var records = [];
        var warnings = [];
        var installed = installedEffectMap();
        var i;
        var sourceLayer;
        var copied;
        var parent;
        var matte;
        var matteType;
        var undoStarted = false;
        if (!nativeFile.exists) { throw new Error("OPLUS_NATIVE_FILE_MISSING: native.aep is missing from this asset."); }
        oldIds = newItemIdsBeforeImport();
        try {
            app.beginUndoGroup("Otiner Studio - Native Import");
            undoStarted = true;
            importOptions = new ImportOptions(nativeFile);
            try { if (importOptions.canImportAs(ImportAsType.PROJECT)) { importOptions.importAs = ImportAsType.PROJECT; } } catch (ignoreImportAs) {}
            app.project.importFile(importOptions);
            relinkPackagedMedia(oldIds, assetDir, options && options.mediaManifest, warnings);
            sourceComp = findImportedComp(compName, oldIds);
            if (!sourceComp) { throw new Error("OPLUS_NATIVE_COMP_MISSING: The exact-copy composition was not found in native.aep."); }
            for (i = sourceComp.numLayers; i >= 1; i -= 1) {
                sourceLayer = sourceComp.layer(i);
                sourceLayer.copyToComp(destination);
                copied = destination.layer(1);
                copiedBySourceIndex[i] = copied;
                records.unshift({ source: sourceLayer, layer: copied, primary: stripMarker(copied) });
                removeUnavailableEffects(copied, installed, warnings);
            }
            for (i = 0; i < records.length; i += 1) {
                parent = read(records[i].source, "parent", null);
                if (parent && copiedBySourceIndex[parent.index]) {
                    try { records[i].layer.parent = copiedBySourceIndex[parent.index]; } catch (ignoreParent) {}
                }
                matte = read(records[i].source, "trackMatteLayer", null);
                matteType = read(records[i].source, "trackMatteType", null);
                if (matte && copiedBySourceIndex[matte.index]) {
                    try {
                        if (typeof records[i].layer.setTrackMatte === "function") {
                            records[i].layer.setTrackMatte(copiedBySourceIndex[matte.index], matteType);
                        } else { records[i].layer.trackMatteType = matteType; }
                    } catch (ignoreMatte) {}
                }
            }
        } finally {
            if (undoStarted) { try { app.endUndoGroup(); } catch (ignoreUndo) {} }
        }
        var result = { mode: "native", layerCount: records.length, layers: [], warnings: warnings };
        for (i = 0; i < records.length; i += 1) {
            result.layers.push({
                name: String(read(records[i].layer, "name", "")),
                index: Number(read(records[i].layer, "index", 0)),
                dependencyOnly: !records[i].primary
            });
        }
        return result;
    }

    nativeApi.saveSelection = saveSelection;
    nativeApi.importSelection = importSelection;
}(typeof $ !== "undefined" && $.global ? $.global : this));
